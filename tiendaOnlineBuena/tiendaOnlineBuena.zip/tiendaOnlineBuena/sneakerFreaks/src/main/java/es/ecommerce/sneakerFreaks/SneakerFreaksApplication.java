package es.ecommerce.sneakerFreaks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SneakerFreaksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SneakerFreaksApplication.class, args);
	}

}
