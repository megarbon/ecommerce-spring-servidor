
@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://com.springbootsoap.allapis", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package allapis.springbootsoap.com;
